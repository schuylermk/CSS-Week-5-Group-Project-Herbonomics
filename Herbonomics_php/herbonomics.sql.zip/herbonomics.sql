-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 10, 2016 at 01:49 PM
-- Server version: 5.5.47-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `herbonomics`
--
CREATE DATABASE IF NOT EXISTS `herbonomics` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `herbonomics`;

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries`
--

CREATE TABLE IF NOT EXISTS `dispensaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `dispensaries`
--

INSERT INTO `dispensaries` (`id`, `name`, `website`, `email`, `username`, `password`) VALUES
(3, 'Chalice Farms', 'www.chalicefarms.com', 'chalicefarms@gmail.com', 'ChaliceFarms', 'test'),
(4, 'Alberta Green House', 'www.albertagreenhouse.com', 'albertagreenhouse@gmail.com', 'AlbertaGreenHouse', 'test'),
(5, 'Pakalolo', 'www.pakalolo.com', 'pakalolo@gmail.com', 'Pakalolo', 'test'),
(6, 'Bridge City Collective', 'www.bridgecitycollective.com', 'info@bridgecitycollective.com', 'BridgeCityCollective', 'test'),
(7, 'Nectar', 'www.nectarpdx.com', 'info@nectarpdx.com', 'Nectar', 'test'),
(8, 'Oregons Finest', 'www.oregonsfinest.com', 'info@oregonsfinest.com', 'OregonsFinest', 'test'),
(9, 'Sirius Extracts', 'www.siriusextracts.com', 'info@siriusextracts.com', 'SiriusExtracts', 'test'),
(10, 'Royal Ambrosia', 'www.royalambrosia.com', 'info@royalambrosia.com', 'RoyalAmbrosia', 'test'),
(11, 'Laurie & MaryJane', 'www.laurieandmaryjane.com', 'laurieandmaryjane@gmail.com', 'LaurieAndMaryJane', 'test'),
(12, 'The Green Planet', 'www.thegreenplanet.com', 'info@thegreenplanet.com', 'TheGreenPlanet', 'test'),
(13, 'Plane Janes Dispensary', 'www.planejanes.com', 'info@planejanes.com', 'PlaneJanes', 'test'),
(14, 'Zion', 'www.zionpdx.com', 'info@zionpdx.com', 'Zion', 'test'),
(15, 'Calyxes', 'www.calyxes.com', 'info@calyxes.com', 'Calyxes', 'test'),
(16, 'One Draw Two', 'www.onedrawtwo.com', 'info@onedrawtwo.com', 'OneDrawTwo', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries_demands`
--

CREATE TABLE IF NOT EXISTS `dispensaries_demands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dispensary_id` int(11) DEFAULT NULL,
  `strain_name` varchar(255) DEFAULT NULL,
  `pheno` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `dispensaries_demands`
--

INSERT INTO `dispensaries_demands` (`id`, `dispensary_id`, `strain_name`, `pheno`, `quantity`) VALUES
(4, 3, 'OG Kush', 'Hybrid', 14),
(5, 3, 'Sour Diesel', 'Sativa', 10),
(6, 3, 'White Widow', 'Hybrid', 8),
(7, 3, 'Grandaddy Purple', 'Indica', 18),
(8, 3, 'Hindu Kush', 'Indica', 13),
(9, 3, 'Blue Cheese', 'Hybrid', 30),
(10, 3, 'NYC Diesel', 'Sativa', 6),
(11, 3, 'Blueberry Haze', 'Hybrid', 10),
(12, 3, 'Blueberry', 'Indica', 10),
(13, 3, 'LA Confidential', 'Indica', 10),
(14, 3, 'Bubba Kush', 'Indica', 5),
(15, 3, 'Northern Lights', 'Sativa', 15),
(16, 3, 'Purple Kush', 'Indica', 1),
(17, 3, 'Trainwreck', 'Sativa', 4),
(18, 4, 'DogWalker OG', 'Hybrid', 5),
(19, 4, 'Trainwreck', 'Sativa', 2),
(20, 4, 'Blue Dream', 'Sativa', 3),
(21, 4, 'Purple Haze ', 'Sativa', 1),
(22, 4, 'Casey Jones', 'Sativa', 2),
(23, 4, 'Strawberry Cough', 'Sativa', 1),
(24, 4, 'Master Kush', 'Hybrid', 1),
(25, 4, 'Jack Herer', 'Hybrid', 1),
(26, 4, 'Lemon Skunk', 'Hybrid', 1),
(27, 4, 'AK-47', 'Hybrid', 1),
(28, 4, 'OG Kush', 'Indica', 1),
(29, 5, 'OG Kush', 'Indica', 2),
(30, 5, 'Blueberry', 'Indica', 1),
(31, 5, 'LA Confidential', 'Indica', 1),
(32, 5, 'Bubba Kush', 'Indica', 2),
(33, 5, 'Strawberry Cough', 'Sativa', 3),
(34, 6, 'Casey Jones', 'Sativa', 2),
(35, 6, 'Trainwreck', 'Sativa', 2),
(36, 6, 'Lemon Skunk', 'Hybrid', 1),
(37, 7, 'Master Kush', 'Hybrid', 2),
(38, 7, 'NYC Diesel', 'Hybrid', 2),
(39, 7, 'OG Kush', 'Indica', 5),
(40, 7, 'Blueberry', 'Indica', 2),
(41, 8, 'Blue Dream', 'Sativa', 5),
(42, 8, 'White Widow', 'Hybrid', 2),
(43, 8, 'Hindu Kush', 'Indica', 2),
(44, 9, 'Sour Diesel', 'Sativa', 40),
(45, 9, 'Trainwreck', 'Sativa', 30),
(46, 9, 'Purple Haze', 'Sativa', 50),
(47, 10, 'NYC Diesel', 'Hybrid', 20),
(48, 10, 'White Widow', 'Hybrid', 10),
(49, 10, 'AK-47', 'Sativa', 10),
(50, 10, 'Bubba Kush', 'Indica', 40),
(51, 11, 'Purple Kush', 'Indica', 50),
(52, 11, 'OG Kush', 'Indica', 70),
(53, 11, 'Bubba Kush', 'Indica', 30),
(54, 11, 'Sour Diesel', 'Sativa', 30),
(55, 12, 'Casey Jones', 'Sativa', 4),
(56, 12, 'Blue Dream', 'Sativa', 8),
(57, 12, 'Purple Kush', 'Indica', 4),
(58, 13, 'Master Kush', 'Hybrid', 2),
(59, 13, 'AK-47', 'Hybrid', 1),
(60, 13, 'Jack Herer', 'Hybrid', 1),
(61, 13, 'NYC Diesel', 'Hybrid', 1),
(62, 13, 'Trainwreck', 'Sativa', 1),
(63, 13, 'Sour Diesel', 'Sativa', 1),
(64, 13, 'Bubba Kush', 'Indica', 3),
(65, 14, 'Blueberry', 'Indica', 3),
(66, 14, 'OG Kush', 'Indica', 1),
(67, 15, 'Grandaddy Purple', 'Sativa', 5),
(68, 15, 'Northern Lights', 'Indica', 5),
(69, 15, 'Blue Dream', 'Sativa', 3),
(70, 15, 'White Widow', 'Hybrid', 1),
(71, 16, 'Master Kush', 'Hybrid', 4),
(72, 16, 'Lemon Skunk', 'Hybrid', 1),
(73, 16, 'Blue Dream', 'Sativa', 5),
(74, 16, 'Sour Diesel', 'Sativa', 5),
(75, 16, 'Purple Kush', 'Indica', 2),
(76, 16, 'OG Kush', 'Indica', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dispensaries_growers`
--

CREATE TABLE IF NOT EXISTS `dispensaries_growers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dispensary_id` int(11) DEFAULT NULL,
  `grower_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `growers`
--

CREATE TABLE IF NOT EXISTS `growers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `growers`
--

INSERT INTO `growers` (`id`, `name`, `website`, `email`, `username`, `password`) VALUES
(2, 'Green Bhodi', 'www.greenbhodifarms.com', 'info@greenbhodifarms.com', 'GreenBhodi', 'test'),
(3, 'Chalice Farms', 'www.chalicefarms.com', 'info@chalicefarms.com', 'ChaliceFarms', 'test'),
(4, '7 Points Oregon', 'www.7pointsoregon.com', 'info@7pointsoregon.com', '7PointsOregon', 'test'),
(5, '7 Points Oregon', 'www.7pointsoregon.com', 'info@7pointsoregon.com', '7PointsOregon', 'test'),
(6, 'Urban Pharms', 'www.urbanpharms.com', 'info@urbanpharms.com', 'UrbanPharms', 'test'),
(7, 'Red Eye Farms', 'www.redeyefarms.com', 'info@redeyefarms.com', 'RedEyeFarms', 'test'),
(8, 'Greeley Gallery', 'www.greelygallery.com', 'info@greeleygallery.com', 'GreeleyGallery', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `growers_strains`
--

CREATE TABLE IF NOT EXISTS `growers_strains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `strain_name` varchar(255) DEFAULT NULL,
  `pheno` varchar(255) DEFAULT NULL,
  `thc` float(5,2) DEFAULT NULL,
  `cbd` float(5,2) DEFAULT NULL,
  `cgc` tinyint(4) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `growers_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `growers_strains`
--

INSERT INTO `growers_strains` (`id`, `strain_name`, `pheno`, `thc`, `cbd`, `cgc`, `price`, `growers_id`) VALUES
(2, 'Sour Diesel', 'Sativa', 24.24, 0.14, 1, 1400, 2),
(3, 'Trainwreck', 'Sativa', 22.43, 0.19, 1, 1500, 2),
(4, 'Blue Dream', 'Sativa', 26.21, 0.09, 1, 1800, 2),
(5, 'Purple Haze', 'Sativa', 20.49, 1.32, 1, 1000, 2),
(6, 'Strawberry Cough', 'Sativa', 19.23, 0.49, 1, 900, 2),
(7, 'White Widow', 'Hybrid', 26.42, 0.05, 1, 1700, 2),
(8, 'AK-47', 'Hybrid', 19.52, 0.08, 1, 1200, 2),
(9, 'Jack Herer', 'Hybrid', 20.79, 0.04, 1, 1500, 2),
(10, 'Lemon Skunk', 'Hybrid', 22.91, 0.09, 1, 1600, 2),
(11, 'Master Kush', 'Hybrid', 20.58, 0.09, 1, 1640, 2),
(12, 'NYC Diesel', 'Hybrid', 19.40, 0.90, 1, 1000, 2),
(13, 'OG Kush', 'Indica', 19.42, 0.24, 1, 1700, 2),
(14, 'Blueberry', 'Indica', 14.20, 2.90, 1, 800, 2),
(15, 'LA Confidential', 'Indica', 23.20, 0.80, 1, 1600, 2),
(16, 'Bubba Kush', 'Indica', 18.43, 0.09, 1, 1300, 2),
(17, 'Northern Lights', 'Hybrid', 14.30, 1.40, 1, 700, 2),
(18, 'Purple Kush', 'Indica', 20.40, 1.30, 1, 1700, 2),
(19, 'OG Kush', 'Indica', 25.20, 0.38, 1, 1500, 3),
(20, 'Blueberry', 'Indica', 21.40, 0.18, 0, 1500, 3),
(21, 'LA Confidential', 'Indica', 17.40, 12.30, 0, 1800, 3),
(22, 'Bubba Kush', 'Indica', 19.87, 0.83, 0, 1600, 3),
(23, 'Northern Lights', 'Indica', 24.87, 0.12, 0, 1700, 3),
(24, 'Purple Kush', 'Indica', 20.80, 0.13, 0, 1500, 3),
(25, 'Sour Diesel', 'Sativa', 26.87, 0.13, 1, 1650, 3),
(26, 'Trainwreck', 'Sativa', 24.32, 0.18, 0, 1800, 3),
(27, 'Blue Dream', 'Sativa', 23.28, 0.15, 0, 1450, 3),
(28, 'Purple Haze', 'Sativa', 15.80, 2.45, 0, 1000, 3),
(29, 'Strawberry Cough', 'Sativa', 21.34, 0.47, 0, 1300, 3),
(30, 'Casey Jones', 'Sativa', 23.32, 0.72, 0, 1300, 3),
(31, 'White Widow', 'Hybrid', 27.43, 0.18, 0, 1560, 3),
(32, 'AK-47', 'Sativa', 30.02, 0.01, 1, 1900, 3),
(33, 'Jack Herer', 'Sativa', 19.30, 0.13, 0, 1200, 3),
(34, 'Lemon Skunk', 'Hybrid', 22.41, 0.37, 0, 1300, 3),
(35, 'Lemon Skunk', 'Hybrid', 19.30, 0.24, 0, 1800, 3),
(36, 'Master Kush', 'Hybrid', 20.31, 0.73, 0, 1300, 3),
(37, 'NYC Diesel', 'Hybrid', 18.43, 0.39, 0, 1450, 3),
(39, 'OG Kush', 'Indica', 22.45, 0.18, 0, 1400, 5),
(40, 'Blueberry', 'Sativa', 23.21, 0.17, 1, 1400, 5),
(41, 'LA Confidential', 'Indica', 19.45, 0.18, 1, 1500, 5),
(42, 'Northern Lights', 'Indica', 29.43, 0.18, 1, 1900, 5),
(43, 'Purple Kush', 'Indica', 23.43, 0.29, 0, 1400, 5),
(44, 'Purple Kush', 'Indica', 24.48, 0.28, 0, 1500, 5),
(45, 'Blue Dream', 'Sativa', 18.40, 0.18, 0, 1900, 5),
(46, 'Strawberry Cough', 'Sativa', 24.54, 0.17, 0, 1400, 5),
(47, 'Trainwreck', 'Sativa', 23.23, 0.89, 0, 1400, 5),
(48, 'White Widow', 'Hybrid', 18.47, 0.14, 0, 1500, 5),
(49, 'AK-47', 'Hybrid', 25.90, 0.28, 1, 1600, 5),
(50, 'Master Kush', 'Hybrid', 23.84, 0.17, 0, 1450, 5),
(51, 'Lemon Skunk', 'Hybrid', 26.78, 0.98, 0, 1300, 5),
(52, 'White Widow', 'Hybrid', 28.47, 0.19, 1, 1700, 6),
(53, 'AK-47', 'Hybrid', 28.45, 0.18, 0, 1600, 6),
(54, 'Jack Herer', 'Hybrid', 29.05, 0.12, 0, 1600, 6),
(55, 'Lemon Skunk', 'Hybrid', 26.98, 0.17, 0, 1600, 6),
(56, 'Master Kush', 'Hybrid', 27.45, 0.17, 0, 1600, 6),
(57, 'NYC Diesel', 'Hybrid', 24.56, 0.18, 1, 1800, 6),
(58, 'Sour Diesel', 'Sativa', 28.45, 0.18, 1, 1800, 7),
(59, 'Trainwreck', 'Sativa', 32.18, 0.18, 1, 1800, 7),
(60, 'Blue Dream', 'Sativa', 29.87, 0.03, 1, 1800, 7),
(61, 'Purple Haze', 'Sativa', 31.08, 0.18, 1, 1800, 7),
(62, 'Strawberry Cough', 'Sativa', 33.40, 0.30, 0, 1800, 7),
(63, 'Casey Jones', 'Sativa', 29.48, 0.17, 0, 1800, 7),
(64, 'OG Kush', 'Indica', 19.48, 0.14, 0, 1300, 8),
(65, 'Blueberry', 'Indica', 18.24, 0.45, 0, 1200, 8),
(66, 'LA Confidential', 'Indica', 18.74, 1.38, 0, 1300, 8),
(67, 'Bubba Kush', 'Indica', 17.32, 0.43, 0, 1200, 8),
(68, 'Northern Lights', 'Indica', 18.39, 0.18, 0, 1600, 8),
(69, 'Purple Kush', 'Indica', 19.30, 0.13, 0, 1300, 8);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
